﻿using MySql.Data.MySqlClient;
using Prueba_Final.Models;
using System.Collections.ObjectModel;
using System.Windows;
using Prueba_Final.Utils;
using System.Collections.Generic;
using System.Windows.Media;

namespace Prueba_Final
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ConnectionDB cDB = new ConnectionDB();

        ObservableCollection<Empleado> ListaEmpleado;
        ObservableCollection<Departamento> ListaDepartamento;

        public MainWindow()
        {
            ListaEmpleado = new ObservableCollection<Empleado>();
            ListaDepartamento = new ObservableCollection<Departamento>();

            InitializeComponent();
            InitData();



        }

        private void GuardarEmpleadoButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult r = MessageBox.Show("Esta seguro de guardar", "Atención", MessageBoxButton.OKCancel);
            if (MessageBoxResult.OK == r)
            {
                cDB.ExecuteSql("insert into empleados (nif,nombre,apellido1,apellido2) values ('" + NifTextBox.Text + "','" + NombreTextBox.Text + "','" + ApellidoTextbox.Text + "','" + Apellido2Textbox.Text + "')");

                LoadEmpleado();
                clearEmpleado();
            }
        }

        private void InitData()
        {
            LoadEmpleado();
            clearEmpleado();

        }

        private void clearEmpleado()

        {
            NifTextBox.Text = "";
            NombreTextBox.Text = "";
            ApellidoTextbox.Text = "";
            Apellido2Textbox.Text = "";

        }


        private void LoadEmpleado()
        {
            ListaEmpleado.Clear();
            MySqlDataReader Reader = cDB.ListaSql("Select nif,nombre,apellido1,apellido2 from empleados ");
            while (Reader.Read())
            {

                Empleado p = new Empleado();

                p.Nif = Reader.GetValue(1).ToString();
                p.Nombre = Reader.GetValue(2).ToString();
                p.Apellido1 = Reader.GetValue(3).ToString();
                p.Apellido2 = Reader.GetValue(4).ToString();
                ListaEmpleado.Add(p);
            }

        }
    }
}
