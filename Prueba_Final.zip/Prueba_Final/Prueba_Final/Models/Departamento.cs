﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_Final.Models
{
     class Departamento
    {
        private string codigo;
        private string nombre;
        private string presupuesto;

        public string Codigo { get => codigo; set => codigo = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Presupuesto { get => presupuesto; set => presupuesto = value; }
    }
}
