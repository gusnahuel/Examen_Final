﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_Final.Models
{
     class Empleado
    {
        private string codigo;
        private string nif;
        private string nombre;
        private string apellido1;
        private string apellido2;

        public string Codigo { get => codigo; set => codigo = value; }
        public string Nif { get => nif; set => nif = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido1 { get => apellido1; set => apellido1 = value; }
        public string Apellido2 { get => apellido2; set => apellido2 = value; }
    }
}
